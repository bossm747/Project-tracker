import { HttpError } from 'wasp/server'

export const createTask = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  return context.entities.Task.create({
    data: {
      description: args.description,
      assignedTo: { connect: { id: args.assignedTo } },
      startDate: args.startDate,
      dueDate: args.dueDate,
      status: args.status
    }
  });
}

export const assignTask = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const task = await context.entities.Task.findUnique({
    where: { id: args.taskId }
  });
  const user = await context.entities.User.findUnique({
    where: { id: args.userId }
  });

  if (!task || !user) { throw new HttpError(404, 'Task or User not found') };

  return context.entities.Task.update({
    where: { id: args.taskId },
    data: { assignedTo: { connect: { id: args.userId } } }
  });
}

export const updateTask = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Task.update({
    where: { id: args.taskId },
    data: {
      description: args.description,
      assignedTo: { connect: { id: args.assignedTo } },
      startDate: args.startDate,
      dueDate: args.dueDate,
      status: args.status
    }
  });
}

export const createFeature = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  return context.entities.Feature.create({
    data: {
      name: args.name,
      description: args.description
    }
  });
}

export const linkFeatureToTask = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  const feature = await context.entities.Feature.findUnique({
    where: { id: args.featureId }
  });
  const task = await context.entities.Task.findUnique({
    where: { id: args.taskId }
  });
  if (!feature || !task) { throw new HttpError(404) };
  return context.entities.Task.update({
    where: { id: args.taskId },
    data: { Feature: { connect: { id: args.featureId } } }
  });
}

export const createNotification = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Notification.create({
    data: {
      userId: args.userId,
      type: args.type,
      content: args.content,
      status: args.status
    }
  });
}