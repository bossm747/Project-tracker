import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useAction, getNotifications, createNotification } from 'wasp/client/operations';

const NotificationPage = () => {
  const { data: notification, isLoading, error } = useQuery(getNotifications);
  const createNotificationFn = useAction(createNotification);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      <h1>{notification.content}</h1>
      <p>{notification.type}</p>
      <p>{notification.status}</p>
      <button onClick={() => createNotificationFn({ userId: notification.userId, type: 'info', content: 'New notification', status: 'unread' })}>Create Notification</button>
    </div>
  );
}

export default NotificationPage;