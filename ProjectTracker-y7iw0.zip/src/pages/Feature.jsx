import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { useQuery, useAction, getFeatures, createFeature, linkFeatureToTask } from 'wasp/client/operations';

const FeaturePage = () => {
  const { featureId } = useParams();
  const { data: features, isLoading, error } = useQuery(getFeatures);
  const createFeatureFn = useAction(createFeature);
  const linkFeatureToTaskFn = useAction(linkFeatureToTask);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleCreateFeature = () => {
    createFeatureFn({ name: 'New Feature', description: 'Description of the new feature' });
  };

  const handleLinkFeatureToTask = (taskId) => {
    linkFeatureToTaskFn({ featureId: parseInt(featureId), taskId });
  };

  return (
    <div className='p-4'>
      {features.map((feature) => (
        <div key={feature.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
          <div>{feature.name}</div>
          <div>{feature.description}</div>
          <button
            onClick={() => handleLinkFeatureToTask(feature.id)}
            className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'>
            Link to Task
          </button>
        </div>
      ))}
      <button
        onClick={handleCreateFeature}
        className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded'>
        Create Feature
      </button>
    </div>
  );
}

export default FeaturePage;