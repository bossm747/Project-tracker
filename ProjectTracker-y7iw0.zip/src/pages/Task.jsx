import React, { useState, useEffect } from 'react';
import { useQuery, useAction, getTasks, updateTask } from 'wasp/client/operations';

const TaskPage = () => {
  const [task, setTask] = useState(null);
  const [updatedDescription, setUpdatedDescription] = useState('');

  const taskId = window.location.pathname.split('/').pop();
  const { data: taskData, isLoading, error } = useQuery(getTasks, { taskId });
  const updateTaskFn = useAction(updateTask);

  useEffect(() => {
    if (taskData) {
      setTask(taskData[0]);
      setUpdatedDescription(taskData[0].description);
    }
  }, [taskData]);

  const handleUpdateTask = () => {
    updateTaskFn({
      id: task.id,
      description: updatedDescription,
      assignedTo: task.assignedTo,
      startDate: task.startDate,
      dueDate: task.dueDate,
      status: task.status
    });
  };

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div>
      {task && (
        <div>
          <h1>{task.description}</h1>
          <input
            type='text'
            value={updatedDescription}
            onChange={(e) => setUpdatedDescription(e.target.value)}
          />
          <button onClick={handleUpdateTask}>Update Task</button>
        </div>
      )}
    </div>
  );
}

export default TaskPage;