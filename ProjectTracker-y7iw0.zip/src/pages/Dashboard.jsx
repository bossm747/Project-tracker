import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery, getTasks, getFeatures, getNotifications } from 'wasp/client/operations';

const Dashboard = () => {
  const { data: tasks, isLoading: tasksLoading, error: tasksError } = useQuery(getTasks);
  const { data: features, isLoading: featuresLoading, error: featuresError } = useQuery(getFeatures);
  const { data: notifications, isLoading: notificationsLoading, error: notificationsError } = useQuery(getNotifications);

  if (tasksLoading || featuresLoading || notificationsLoading) return 'Loading...';
  if (tasksError || featuresError || notificationsError) return 'Error: ' + (tasksError || featuresError || notificationsError);

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>Project Overview</h1>
      <div className='mb-4'>
        <h2 className='text-lg font-bold'>Tasks</h2>
        {tasks.map((task) => (
          <div key={task.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
            <div>{task.description}</div>
            <div>Assigned To: {task.assignedTo.username}</div>
            <div>Start Date: {task.startDate}</div>
            <div>Due Date: {task.dueDate}</div>
            <div>Status: {task.status}</div>
          </div>
        ))}
      </div>
      <div className='mb-4'>
        <h2 className='text-lg font-bold'>Features</h2>
        {features.map((feature) => (
          <div key={feature.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
            <div>{feature.name}</div>
            <div>Description: {feature.description}</div>
          </div>
        ))}
      </div>
      <div>
        <h2 className='text-lg font-bold'>Notifications</h2>
        {notifications.map((notification) => (
          <div key={notification.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
            <div>Type: {notification.type}</div>
            <div>{notification.content}</div>
            <div>Status: {notification.status}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Dashboard;