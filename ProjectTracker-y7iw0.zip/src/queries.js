import { HttpError } from 'wasp/server'

export const getTasks = async (arg, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Task.findMany({
    where: {
      userId: arg.userId
    }
  });
}

export const getFeatures = async (arg, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Feature.findMany();
}

export const getNotifications = async (arg, context) => {
  if (!context.user) { throw new HttpError(401) }

  const notifications = await context.entities.Notification.findMany({ where: { userId: arg.userId } });

  return notifications;
}